--############    ######            ###
--############    ######            ###
--###      ###    ###   ###         ###
--###      ###    ###   ###         ###
--###      ###    ######            ###
--###      ###    ######            ###
--###      ###    ###   ###         ###
--###      ###    ###   ###         ###
--###      ###    ###   ###         ###
--###      ###    ###   ###         ###
--############    ######      ######
--############    ######      ######


minetest.register_node("more_blocks:skin", {
	description = "Tree",
	drawtype = "mesh",
	mesh = "more_blocks_model.obj",
	drop = "more_blocks:skin",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",fixed = {
			{-0.4, -0.5, -0.5, -0.5, 0.5, 0.5},
			{0.4, -0.5, -0.5, 0.5, 0.5, 0.5}}},
	tiles = {"more_blocks_skin.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:skin2", {
	description = "Tree2",
	drawtype = "mesh",
	mesh = "more_blocks_model2.obj",
	drop = "more_blocks:skin2",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",fixed = {
			{-0.5, -0.5, -0.5, -0.5, 0.5, 0.5}}},
	tiles = {"more_blocks_skin.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:vent", {
	description = "vent",
	drawtype = "mesh",
	mesh = "more_blocks_vent.obj",
	drop = "more_blocks:vent",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",fixed = {
			{-0.4, -0.5, -0.5, -0.5, 0.5, 0.5},
			{0.4, -0.5, -0.5, 0.5, 0.5, 0.5}}},
	tiles = {"more_blocks_vent.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:switch", {
	description = "switch",
	drawtype = "mesh",
	mesh = "more_blocks_switch.obj",
	drop = "more_blocks:switch",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",fixed = {
			{-0.0, -0.0, -0.0, -0.0, 0.0, 0.0}}},
	tiles = {"more_blocks_switch.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:skull", {
	description = "skull",
	drawtype = "mesh",
	mesh = "more_blocks_skull.obj",
	drop = "more_blocks:skull",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",fixed = {
			{-0.4, -0.5, -0.5, -0.5, 0.5, 0.5},
			{0.4, -0.5, -0.5, 0.5, 0.5, 0.5}}},
	tiles = {"more_blocks_skull.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:lol", {
	description = "lol",
	drawtype = "mesh",
	mesh = "more_blocks_lol.obj",
	drop = "more_blocks:lol",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",
		fixed = {-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}
    },
	tiles = {"more_blocks_lol.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:cctable", {
	description = "cctable",
	drawtype = "mesh",
	mesh = "more_blocks_cctable.obj",
	drop = "more_blocks:cctable",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-2.5, -0.5, -1.5, 2.5, 0.5, 1.5}
	},
collision_box = {
		type = "fixed",
		fixed = {-1.0, -0.5, -0.1, 1.0, 0.5, 0.1}
    },
	tiles = {"more_blocks_cctable.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:sign", {
	description = "sign",
	drawtype = "mesh",
	mesh = "more_blocks_sign.obj",
	drop = "more_blocks:sign",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	node_box = {
		type = "wallmounted",
		wall_top    = {-0.4375, 0.4375, -0.3125, 0.4375, 0.5, 0.3125},
		wall_bottom = {-0.4375, -0.5, -0.3125, 0.4375, -0.4375, 0.3125},
		wall_side   = {-0.5, -0.3125, -0.4375, -0.4375, 0.3125, 0.4375},
	},
	tiles = {"more_blocks_sign.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

minetest.register_node("more_blocks:no_exit", {
	description = "no_exit",
	drawtype = "mesh",
	mesh = "more_blocks_no_exit.obj",
	drop = "more_blocks:no_exit",
	wield_scale = {x=0.5, y=0.5, z=0.5},
selection_box = {
		type = "fixed",
		fixed = {-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}
	},
collision_box = {
		type = "fixed",
		fixed = {-1.0, -0.5, -0.1, 1.0, 0.5, 0.1}
    },
	tiles = {"more_blocks_no_exit.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
on_rightclick = function(pos, node, player, itemstack, pointed_thing)
	minetest.swap_node(pos, {name="more_blocks:test", param2=minetest.get_node(pos).param2})
	end,
})

