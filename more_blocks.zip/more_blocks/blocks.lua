local chest_formspec =
	"size[9,9.75]"..
	"background[-0.19,-0.25;9.41,10.48;crafting_inventory_chest.jpg]"..
	"bgcolor[#080808BB;true]"..
	"listcolors[#9990;#FFF7;#FFF0;#160816;#D4D2FF]"..
	"list[current_name;main;0,0.5;9,4;]"..
	"list[current_player;main;0,5.5;9,3;9]"..
	"list[current_player;main;0,8.74;9,1;]"

local function drop_chest_stuff()
	return function(pos, oldnode, oldmetadata, digger)
		local meta = minetest.get_meta(pos)
		meta:from_table(oldmetadata)
		local inv = meta:get_inventory()
		for i=1,inv:get_size("main") do
			local stack = inv:get_stack("main", i)
			if not stack:is_empty() then
				local p = {x=pos.x+math.random(0, 5)/5-0.5, y=pos.y, z=pos.z+math.random(0, 5)/5-0.5}
				minetest.add_item(p, stack)
			end
		end
	end
end

minetest.register_node("more_blocks:box", {
	description = "Box",
	tiles = {"more_blocks_box_side.jpg", "more_blocks_box_side.jpg", "more_blocks_box_top.jpg",
		"more_blocks_box_top.jpg", "more_blocks_box_top.jpg", "more_blocks_box_top.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Box")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1a", {
	description = "Yellow Crate",
	tiles = {"more_blocks_crate1a.jpg", "more_blocks_crate1a.jpg", "more_blocks_crate1a.jpg",
		"more_blocks_crate1a.jpg", "more_blocks_crate1a.jpg", "more_blocks_crate1a.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Yellow Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1b", {
	description = "Blue Crate",
	tiles = {"more_blocks_crate1b.jpg", "more_blocks_crate1b.jpg", "more_blocks_crate1b.jpg",
		"more_blocks_crate1b.jpg", "more_blocks_crate1b.jpg", "more_blocks_crate1b.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Blue Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1c", {
	description = "Green Crate",
	tiles = {"more_blocks_crate1c.jpg", "more_blocks_crate1c.jpg", "more_blocks_crate1c.jpg",
		"more_blocks_crate1c.jpg", "more_blocks_crate1c.jpg", "more_blocks_crate1c.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Green Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1d", {
	description = "Red Crate",
	tiles = {"more_blocks_crate1d.jpg", "more_blocks_crate1d.jpg", "more_blocks_crate1d.jpg",
		"more_blocks_crate1d.jpg", "more_blocks_crate1d.jpg", "more_blocks_crate1d.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Red Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1e", {
	description = "Grey Crate",
	tiles = {"more_blocks_crate1e.jpg", "more_blocks_crate1e.jpg", "more_blocks_crate1e.jpg",
		"more_blocks_crate1e.jpg", "more_blocks_crate1e.jpg", "more_blocks_crate1e.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Grey Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:crate1_s", {
	description = "Black Crate",
	tiles = {"more_blocks_crate1_s.jpg", "more_blocks_crate1_s.jpg", "more_blocks_crate1_s.jpg",
		"more_blocks_crate1_s.jpg", "more_blocks_crate1_s.jpg", "more_blocks_crate1_s.jpg"},
	paramtype2 = "facedir",
	groups = {choppy=2,oddly_breakable_by_hand=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", chest_formspec)
		meta:set_string("infotext", "Black Crate")
		local inv = meta:get_inventory()
		inv:set_size("main", 10*5)
	end,

    on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to chest at "..minetest.pos_to_string(pos))
	end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from chest at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_node("more_blocks:metal_door", {
	description = "skull",
	drawtype = "nodebox",
	drop = "more_blocks:metal_door",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"more_blocks_metal_door.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = false,
	is_ground_content = true,
})

minetest.register_node("more_blocks:e7sbrickfloor_s", {
	description = "e7sbrickfloor_s",
	tiles = {"more_blocks_e7sbrickfloor_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:1r_floor02", {
	description = "1r_floor02",
	tiles = {"more_blocks_1r_floor02.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:1r_squ_pan03", {
	description = "1r_squ_pan03",
	tiles = {"more_blocks_1r_squ_pan03.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e7sbrickfloor_ow_s", {
	description = "e7sbrickfloor_ow_s",
	drawtype = "nodebox",
	drop = "more_blocks:e7sbrickfloor_ow_s",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"more_blocks_e7sbrickfloor_ow_s.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = false,
	is_ground_content = true,
})

minetest.register_node("more_blocks:e6metalfan", {
	description = "e6metalfan",
	tiles = {"more_blocks_e6metalfan.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor06", {
	description = "floor06",
	tiles = {"more_blocks_floor06.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e7dimfloor_ow_s", {
	description = "e7dimfloor_ow_s",
	tiles = {"more_blocks_e7dimfloor_ow_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e7dimfloor_s", {
	description = "e7dimfloor_s",
	tiles = {"more_blocks_e7dimfloor_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:stripes", {
	description = "stripes",
	tiles = {"more_blocks_stripes.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:jp11a", {
	description = "jp11a",
	tiles = {"more_blocks_jp11a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:worldmap", {
	description = "worldmap",
	drawtype = "nodebox",
	drop = "more_blocks:worldmap",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"more_blocks_worldmap.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = false,
	is_ground_content = true,
})

minetest.register_node("more_blocks:worldmap2", {
	description = "worldmap2",
	drawtype = "nodebox",
	drop = "more_blocks:worldmap2",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"more_blocks_worldmap2.jpg"},
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_stone_defaults(),
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = false,
	is_ground_content = true,
})

minetest.register_node("more_blocks:e6platelight", {
	description = "e6platelight",
	tiles = {"more_blocks_e6platelight.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6platelight_burnt_z", {
	description = "e6platelight_burnt_z",
	tiles = {"more_blocks_e6platelight_burnt_z.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6symbol_a", {
	description = "e6symbol_a",
	tiles = {"more_blocks_e6symbol_a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6symbol_b", {
	description = "e6symbol_b",
	tiles = {"more_blocks_e6symbol_b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6symbol_c", {
	description = "e6symbol_c",
	tiles = {"more_blocks_e6symbol_c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6symbol_d", {
	description = "e6symbol_d",
	tiles = {"more_blocks_e6symbol_d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:e6tinylight", {
	description = "e6tinylight",
	drawtype = "glasslike",
	tiles = {"more_blocks_e6tinylight.jpg"},
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky = 3, oddly_breakable_by_hand = 3},
	sounds = default.node_sound_glass_defaults(),
	light_source = 15,
})

minetest.register_node("more_blocks:e6tinylight_z", {
	description = "e6tinylight_z",
	drawtype = "glasslike",
	tiles = {"more_blocks_e6tinylight_z.jpg"},
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky = 3, oddly_breakable_by_hand = 3},
	sounds = default.node_sound_glass_defaults(),
	light_source = 15,
})

minetest.register_node("more_blocks:e6walllight", {
	description = "e6walllight",
	drawtype = "glasslike",
	tiles = {"more_blocks_e6walllight.jpg"},
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky = 3, oddly_breakable_by_hand = 3},
	sounds = default.node_sound_glass_defaults(),
	light_source = 15,
})

minetest.register_node("more_blocks:s12801c", {
	description = "s128-01c",
	tiles = {"more_blocks_s128-01c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:s25602a", {
	description = "s256-02a",
	tiles = {"more_blocks_s256-02a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:solid_vent", {
	description = "solid_vent",
	tiles = {"more_blocks_solid_vent.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:orange", {
	description = "orange",
	tiles = {{
		name="orange.png",
		animation={type="vertical_frames", aspect_w=100, aspect_h=100, length=1},
	}},
	is_ground_content = true,
	light_source = default.LIGHT_MAX - 1,
	groups = {cracky=2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:base1a", {
	description = "base1a",
	tiles = {"more_blocks_base1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:base1c", {
	description = "base1c",
	tiles = {"more_blocks_base1c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:ceil1a", {
	description = "ceil1a",
	tiles = {"more_blocks_ceil1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:ceil1_s", {
	description = "ceil1_s",
	tiles = {"more_blocks_ceil1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2a", {
	description = "floor2a",
	tiles = {"more_blocks_floor2a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2b", {
	description = "floor2b",
	tiles = {"more_blocks_floor2b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2c", {
	description = "floor2c",
	tiles = {"more_blocks_floor2c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2d", {
	description = "floor2d",
	tiles = {"more_blocks_floor2d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2e", {
	description = "floor2e",
	tiles = {"more_blocks_floor2e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:floor2f", {
	description = "floor2f",
	tiles = {"more_blocks_floor2f.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:grate1a", {
	description = "grate1a",
	tiles = {"more_blocks_grate1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:grate1_s", {
	description = "grate1_s",
	tiles = {"more_blocks_grate1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:graypanel1", {
	description = "graypanel1",
	tiles = {"more_blocks_graypanel1.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:graypanel1_s", {
	description = "graypanel1_s",
	tiles = {"more_blocks_graypanel1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:graypanel2", {
	description = "graypanel2",
	tiles = {"more_blocks_graypanel2.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:graypanel2_s", {
	description = "graypanel2_s",
	tiles = {"more_blocks_graypanel2_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:graypanel3", {
	description = "graypanel3",
	tiles = {"more_blocks_graypanel3.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:holes1a", {
	description = "holes1a",
	tiles = {"more_blocks_holes1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:holes1b", {
	description = "holes1b",
	tiles = {"more_blocks_holes1b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:holes1_s", {
	description = "holes1_s",
	tiles = {"more_blocks_holes1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:light2a", {
	description = "light2a",
	drawtype = "glasslike",
	tiles = {"more_blocks_light2a.jpg"},
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky = 3, oddly_breakable_by_hand = 3},
	sounds = default.node_sound_glass_defaults(),
	light_source = 15,
})


minetest.register_node("more_blocks:panel1a", {
	description = "panel1a",
	tiles = {"more_blocks_panel1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:panel1_s", {
	description = "panel1_s",
	tiles = {"more_blocks_panel1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:panel2a", {
	description = "panel2a",
	tiles = {"more_blocks_panel2a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:panel2_s", {
	description = "panel2_s",
	tiles = {"more_blocks_panel2_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:pipez1a", {
	description = "pipez1a",
	tiles = {"more_blocks_pipez1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:pits1a", {
	description = "pits1a",
	tiles = {"more_blocks_pits1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:pits1_s", {
	description = "pits1_s",
	tiles = {"more_blocks_pits1_s.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:ribs1a", {
	description = "ribs1a",
	tiles = {"more_blocks_ribs1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:thingy1a", {
	description = "thingy1a",
	tiles = {"more_blocks_thingy1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile1a", {
	description = "tile1a",
	tiles = {"more_blocks_tile1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile1b", {
	description = "tile1b",
	tiles = {"more_blocks_tile1b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile1c", {
	description = "tile1c",
	tiles = {"more_blocks_tile1c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile1d", {
	description = "tile1d",
	tiles = {"more_blocks_tile1d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile1e", {
	description = "tile1e",
	tiles = {"more_blocks_tile1e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile2a", {
	description = "tile2a",
	tiles = {"more_blocks_tile2a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile2b", {
	description = "tile2b",
	tiles = {"more_blocks_tile2b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile2c", {
	description = "tile2c",
	tiles = {"more_blocks_tile2c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile2d", {
	description = "tile2d",
	tiles = {"more_blocks_tile2d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile3a", {
	description = "tile3a",
	tiles = {"more_blocks_tile3a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile3b", {
	description = "tile3b",
	tiles = {"more_blocks_tile3b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile3c", {
	description = "tile3c",
	tiles = {"more_blocks_tile3c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile3d", {
	description = "tile3d",
	tiles = {"more_blocks_tile3d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile3e", {
	description = "tile3e",
	tiles = {"more_blocks_tile3e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile4a", {
	description = "tile4a",
	tiles = {"more_blocks_tile4a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile4b", {
	description = "tile4b",
	tiles = {"more_blocks_tile4b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile4c", {
	description = "tile4c",
	tiles = {"more_blocks_tile4c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile4d", {
	description = "tile4d",
	tiles = {"more_blocks_tile4d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile4e", {
	description = "tile4e",
	tiles = {"more_blocks_tile4e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile5a", {
	description = "tile5a",
	tiles = {"more_blocks_tile5a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile5b", {
	description = "tile5b",
	tiles = {"more_blocks_tile5b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile5c", {
	description = "tile5c",
	tiles = {"more_blocks_tile5c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile5d", {
	description = "tile5d",
	tiles = {"more_blocks_tile5d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:tile5e", {
	description = "tile5e",
	tiles = {"more_blocks_tile5e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall1a", {
	description = "wall1a",
	tiles = {"more_blocks_wall1a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall1b", {
	description = "wall1b",
	tiles = {"more_blocks_wall1b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall1c", {
	description = "wall1c",
	tiles = {"more_blocks_wall1c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall1d", {
	description = "wall1d",
	tiles = {"more_blocks_wall1d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall1e", {
	description = "wall1e",
	tiles = {"more_blocks_wall1e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall2a", {
	description = "wall2a",
	tiles = {"more_blocks_wall2a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall2b", {
	description = "wall2b",
	tiles = {"more_blocks_wall2b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall2c", {
	description = "wall2c",
	tiles = {"more_blocks_wall2c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall2d", {
	description = "wall2d",
	tiles = {"more_blocks_wall2d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall2e", {
	description = "wall2e",
	tiles = {"more_blocks_wall2e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall3a", {
	description = "wall3a",
	tiles = {"more_blocks_wall3a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall3b", {
	description = "wall3b",
	tiles = {"more_blocks_wall3b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall3c", {
	description = "wall3c",
	tiles = {"more_blocks_wall3c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall3d", {
	description = "wall3d",
	tiles = {"more_blocks_wall3d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall3e", {
	description = "wall3e",
	tiles = {"more_blocks_wall3e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall4a", {
	description = "wall4a",
	tiles = {"more_blocks_wall4a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall4b", {
	description = "wall4b",
	tiles = {"more_blocks_wall4b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall4c", {
	description = "wall4c",
	tiles = {"more_blocks_wall4c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall4d", {
	description = "wall4d",
	tiles = {"more_blocks_wall4d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall4e", {
	description = "wall4e",
	tiles = {"more_blocks_wall4e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall5a", {
	description = "wall5a",
	tiles = {"more_blocks_wall5a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall5b", {
	description = "wall5b",
	tiles = {"more_blocks_wall5b.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall5c", {
	description = "wall5c",
	tiles = {"more_blocks_wall5c.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall5d", {
	description = "wall5d",
	tiles = {"more_blocks_wall5d.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall5e", {
	description = "wall5e",
	tiles = {"more_blocks_wall5e.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("more_blocks:wall6a", {
	description = "wall6a",
	tiles = {"more_blocks_wall6a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("more_blocks:wall7a", {
	description = "wall7a",
	tiles = {"more_blocks_wall7a.jpg"},
	is_ground_content = false,
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

--minetest.register_node("more_blocks:brick", {
--	description = "Ziegel Block",
--	tiles = {"more_blocks_brick.jpg"},
--	is_ground_content = false,
--	groups = {cracky=3},
--	sounds = default.node_sound_stone_defaults(),
--})


